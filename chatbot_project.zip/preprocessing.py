# preprocessing.py
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

nltk.download('punkt')
nltk.download('stopwords')

def preprocess_input(user_input):
    # Tokenize the user input
    tokens = word_tokenize(user_input)

    # Remove stopwords
    stop_words = set(stopwords.words('english'))
    filtered_tokens = [word for word in tokens if word.lower() not in stop_words]

    # Join tokens back to a string
    processed_input = ' '.join(filtered_tokens)
    return processed_input
