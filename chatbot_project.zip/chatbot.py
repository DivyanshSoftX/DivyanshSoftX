# chatbot.py
from preprocessing import preprocess_input
from model import ChatbotModel

class Chatbot:
    def __init__(self):
        self.model = ChatbotModel()

    def get_response(self, user_input):
        processed_input = preprocess_input(user_input)
        response = self.model.generate_response(processed_input)
        return response

if __name__ == "__main__":
    chatbot = Chatbot()
    print("AI Chatbot: Hello! Ask me anything.")
    while True:
        user_input = input("You: ")
        if user_input.lower() in ["quit", "exit"]:
            print("AI Chatbot: Goodbye!")
            break
        response = chatbot.get_response(user_input)
        print(f"AI Chatbot: {response}")
