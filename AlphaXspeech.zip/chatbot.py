# chatbot.py
import speech_recognition as sr
import pyttsx3
from preprocessing import preprocess_input
from model import ChatbotModel

class Chatbot:
    def __init__(self):
        self.model = ChatbotModel()
        self.engine = pyttsx3.init()  # Initialize the TTS engine

    def speak(self, text):
        """Convert text to speech."""
        self.engine.say(text)
        self.engine.runAndWait()

    def listen(self):
        """Capture audio input and convert it to text."""
        recognizer = sr.Recognizer()
        with sr.Microphone() as source:
            print("AI Chatbot: Listening...")
            audio = recognizer.listen(source)

        try:
            user_input = recognizer.recognize_google(audio)
            print(f"You: {user_input}")
            return user_input
        except sr.UnknownValueError:
            print("AI Chatbot: Sorry, I could not understand that.")
            return None
        except sr.RequestError:
            print("AI Chatbot: Could not request results, check your network.")
            return None

    def get_response(self, user_input):
        processed_input = preprocess_input(user_input)
        response = self.model.generate_response(processed_input)
        return response

if __name__ == "__main__":
    chatbot = Chatbot()
    chatbot.speak("Hello! How can I assist you today?")

    while True:
        user_input = chatbot.listen()

        if user_input:
            if user_input.lower() in ["quit", "exit"]:
                chatbot.speak("Goodbye!")
                break
            response = chatbot.get_response(user_input)
            print(f"AI Chatbot: {response}")
            chatbot.speak(response)
